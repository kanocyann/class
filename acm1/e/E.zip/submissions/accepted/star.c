#include<stdio.h>
int main ()
{
    printf("Welcome to HLJU");
}
