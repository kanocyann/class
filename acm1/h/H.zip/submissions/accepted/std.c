#include<stdio.h>
int main()
{
    int n,x,t,y;
    scanf("%d%d%d%d",&n,&x,&t,&y);
    int ans=0;
    for(int i=1;i<=n;i++)
    {
        int a;
        scanf("%d",&a);
        ans+=(a+x-1)/x;
    }
    t-=(n*y);
    if(t<0) printf("no");
    else
    {
        t*=60;
        if(t>=ans) printf("yes");
        else printf("no");
    }
    return 0;
}
