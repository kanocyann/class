#include<stdio.h>
int main()
{
    double n,v1,v2;
    scanf("%lf%lf%lf",&n,&v1,&v2);
    double ans=2.0*n/v1+n/v2;
    printf("%.8lf\n",ans);
}
