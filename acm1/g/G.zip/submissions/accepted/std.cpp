#include<stdio.h>
int a[110];
int max(int a,int b){return a>b?a:b;}
int min(int a,int b){return a>b?b:a;}
int main()
{
    int n;
    scanf("%d",&n);
    for(int i=0;i<n;i++)
        scanf("%d",&a[i]);
    int mi1=1e6,mi2=1e6,ma=0;
    for(int i=0;i<n;i++)
    {
        ma=max(ma,a[i]);
        if(a[i]<mi1)
        {
            mi2=mi1;
            mi1=a[i];
        }
        else if(a[i]<mi2)
            mi2=a[i];
    }
    int mi=(mi1+ma)/2;
    printf("%d\n",mi<mi2?mi:mi2);
}
