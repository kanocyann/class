#include<ctime>
#include<cstdlib>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<string>
#include<cmath>
#include<vector>
#include<unordered_map>
using namespace std;
typedef long long ll;
const int test_num = 10;
string in_s = ".in", ans_s = ".ans";
const int N = 100010;
int n;
int a[N];
void solve()
{
    int mi1=1e6,mi2=1e6,ma=0;
    for(int i=0;i<n;i++)
    {
        ma=max(ma,a[i]);
        if(a[i]<mi1)
        {
            mi2=mi1;
            mi1=a[i];
        }
        else if(a[i]<mi2)
            mi2=a[i];
    }
    int mi=(mi1+ma)/2;
    printf("%d\n",mi<mi2?mi:mi2);
}

signed main()
{
	srand((ll)time(NULL));
	string in, ans;
	for (int i = 1; i <= 20; i ++ )
	{
		in = to_string(i) + in_s;
		ans = to_string(i) + ans_s;
		freopen(in.c_str(), "w", stdout);
        n = rand()%90+10;
        if(i==19) n=100;
        cout<<n<<"\n";
        for(int j=0;j<n;j++)
        {
            if(i==19) a[j]=rand()%900000+10000;
            else a[j]=rand()%90000+10000;
            if(i%4==0) a[j]=rand()%100+900000;
            if(i%4==0&&j==n-1) a[j]=1;
            cout<<a[j]<<" ";
        }
		freopen(ans.c_str(), "w", stdout);
		//cout << i << endl;
		freopen(in.c_str(),"r",stdin);
		solve();
	}
}
