#include<stdio.h>
int main()
{
    int n,k;
    scanf("%d%d",&n,&k);
    int sum=0;
    int ans=1;
    int i;
    for(i=1;i<=n;i++)
    {
        int z;
        scanf("%d",&z);
        if(sum+z>k)
        {
            ans++;
            sum=z;
        }
        else sum+=z;
    }
    printf("%d\n",ans);
}
